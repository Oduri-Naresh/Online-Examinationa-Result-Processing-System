from django.apps import AppConfig


class ExamsAppConfig(AppConfig):
    name = 'exams_app'
